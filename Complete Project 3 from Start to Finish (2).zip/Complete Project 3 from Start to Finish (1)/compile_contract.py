#!/usr/bin/env python3

"""
Compiles the Solidity smart contract using py-solc-x.
"""

import json
import os
from solcx import compile_standard, install_solc

def compile_contract(contract_source_path, contract_name):
    """Compiles the Solidity contract and returns ABI and bytecode."""
    print("Checking/Installing Solidity compiler...")
    # Automatically install compatible solc version if needed
    # Let's try a recent stable version compatible with ^0.8.0
    try:
        install_solc("0.8.17") 
    except Exception as e:
        print(f"Failed to install solc 0.8.20 automatically: {e}")
        print("Please ensure a compatible Solidity compiler (e.g., 0.8.x) is installed and accessible.")
        return None, None

    print(f"Compiling contract: {contract_source_path}...")
    with open(contract_source_path, "r") as file:
        contract_source_code = file.read()

    compiled_sol = compile_standard(
        {
            "language": "Solidity",
            "sources": {os.path.basename(contract_source_path): {"content": contract_source_code}},
            "settings": {
                "outputSelection": {
                    "*": {
                        "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"]
                    }
                }
            },
        },
        solc_version="0.8.17",
    )

    # Save compiled output for inspection (optional)
    compiled_output_path = "compiled_contract.json"
    with open(compiled_output_path, "w") as file:
        json.dump(compiled_sol, file, indent=4)
    print(f"Compiled output saved to {compiled_output_path}")

    # Extract ABI and Bytecode
    try:
        bytecode = compiled_sol["contracts"][os.path.basename(contract_source_path)][contract_name]["evm"]["bytecode"]["object"]
        abi = json.loads(compiled_sol["contracts"][os.path.basename(contract_source_path)][contract_name]["metadata"])["output"]["abi"]
    except KeyError as e:
        print(f"Error extracting ABI/Bytecode: {e}")
        print("Please check the contract name and compilation output.")
        return None, None

    print("Contract compiled successfully.")
    return abi, bytecode

if __name__ == "__main__":
    contract_file = "ProductRegistry.sol"
    main_contract_name = "ProductRegistry"
    abi, bytecode = compile_contract(contract_file, main_contract_name)

    if abi and bytecode:
        # Save ABI and bytecode to separate files for deployment script
        with open("contract_abi.json", "w") as f:
            json.dump(abi, f)
        with open("contract_bytecode.bin", "w") as f:
            f.write(bytecode)
        print("ABI saved to contract_abi.json")
        print("Bytecode saved to contract_bytecode.bin")
    else:
        print("Compilation failed.")

