#!/usr/bin/env python3

"""
Deploys the compiled ProductRegistry smart contract to a local blockchain (Ganache).
"""

import json
from web3 import Web3
import os

# Configuration
GANACHE_URL = "http://127.0.0.1:8545" # Default Ganache RPC server URL
ABI_PATH = "contract_abi.json"
BYTECODE_PATH = "contract_bytecode.bin"
CONFIG_OUTPUT_PATH = "contract_config.json"

def deploy_contract(w3, abi, bytecode):
    """Deploys the contract using the first account from the node."""
    # Set default account (Ganache provides pre-funded accounts)
    try:
        w3.eth.default_account = w3.eth.accounts[0]
        print(f"Using account: {w3.eth.default_account}")
    except IndexError:
        print("Error: No accounts found in Ganache. Is Ganache running?")
        return None

    # Create contract instance
    ProductRegistry = w3.eth.contract(abi=abi, bytecode=bytecode)

    print("Deploying contract...")
    # Submit the transaction that deploys the contract
    try:
        tx_hash = ProductRegistry.constructor().transact()
        print(f"Transaction hash: {tx_hash.hex()}")

        # Wait for the transaction to be mined, and get the transaction receipt
        print("Waiting for transaction receipt...")
        tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        print(f"Contract deployed successfully!")
        print(f"Contract address: {tx_receipt.contractAddress}")
        return tx_receipt.contractAddress
    except Exception as e:
        print(f"Error deploying contract: {e}")
        # Check Ganache logs (/home/ubuntu/ganache.log) for more details
        return None

if __name__ == "__main__":
    # Connect to Ganache
    web3_instance = Web3(Web3.HTTPProvider(GANACHE_URL))

    if not web3_instance.is_connected():
        print(f"Failed to connect to Ganache at {GANACHE_URL}")
        exit(1)

    print(f"Connected to Ganache: {GANACHE_URL}")

    # Load ABI and Bytecode
    try:
        with open(ABI_PATH, "r") as f:
            contract_abi = json.load(f)
        with open(BYTECODE_PATH, "r") as f:
            contract_bytecode = f.read()
    except FileNotFoundError as e:
        print(f"Error loading ABI/Bytecode: {e}. Did compilation succeed?")
        exit(1)

    # Deploy
    contract_address = deploy_contract(web3_instance, contract_abi, contract_bytecode)

    # Save configuration
    if contract_address:
        config_data = {
            "contract_address": contract_address,
            "abi": contract_abi,
            "rpc_url": GANACHE_URL
        }
        with open(CONFIG_OUTPUT_PATH, "w") as f:
            json.dump(config_data, f, indent=4)
        print(f"Contract configuration saved to {CONFIG_OUTPUT_PATH}")
    else:
        print("Contract deployment failed. Configuration not saved.")
        exit(1)

