#!/usr/bin/env python3

import sys
import os
import json
from flask import Flask, request, jsonify, render_template
from web3 import Web3

# Ensure the src directory is in the Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

app = Flask(__name__)

# --- Blockchain Configuration --- 
# TODO: Update these values after deploying to a public testnet (Step 014)
# Using Ganache details for now
GANACHE_URL = "http://127.0.0.1:8545" 
CONTRACT_ADDRESS = "0xaD7A4354CE650cFee6746e6F1FE6C358696080fB"
ABI_PATH = os.path.join(os.path.dirname(__file__), "contract_abi.json")

# Load Contract ABI
try:
    with open(ABI_PATH, "r") as f:
        CONTRACT_ABI = json.load(f)
except FileNotFoundError:
    print(f"Error: ABI file not found at {ABI_PATH}")
    CONTRACT_ABI = None
except json.JSONDecodeError:
    print(f"Error: Could not decode ABI file at {ABI_PATH}")
    CONTRACT_ABI = None

# Initialize Web3
w3 = Web3(Web3.HTTPProvider(GANACHE_URL))

# Instantiate Contract (if ABI loaded successfully)
if CONTRACT_ABI and w3.is_connected():
    product_registry_contract = w3.eth.contract(address=CONTRACT_ADDRESS, abi=CONTRACT_ABI)
    print("Successfully connected to blockchain and loaded contract.")
else:
    product_registry_contract = None
    print("Error: Could not connect to blockchain or load contract ABI. Verification endpoint will fail.")

# --- Routes --- 

@app.route("/")
def index():
    """Serves the main HTML page."""
    # The static folder is configured to serve index.html from src/static/
    # However, Flask default looks for templates, so let's explicitly render it.
    # For deployment, ensure index.html is in the correct static path.
    # The template uses src/static/index.html
    return render_template("index.html")

@app.route("/verify", methods=["POST"])
def verify_barcode():
    """Handles barcode verification requests."""
    if not product_registry_contract:
        return jsonify({"error": "Blockchain connection/contract not initialized"}), 500
        
    data = request.get_json()
    if not data or "barcode" not in data:
        return jsonify({"error": "Missing barcode in request"}), 400

    barcode = data["barcode"]

    try:
        print(f"Verifying barcode: {barcode}")
        is_genuine = product_registry_contract.functions.isProductGenuine(barcode).call()
        print(f"Verification result for {barcode}: {is_genuine}")
        return jsonify({"is_genuine": is_genuine})
    except Exception as e:
        print(f"Error verifying barcode {barcode}: {e}")
        # Return false for any contract interaction error
        # Consider more specific error handling for production
        return jsonify({"is_genuine": False, "error": str(e)}), 500

# --- Main Execution --- 

if __name__ == "__main__":
    # Run the app (for local testing)
    # For deployment, a WSGI server like Gunicorn will be used.
    # Ensure host is 0.0.0.0 to be accessible externally if needed for testing
    app.run(host="0.0.0.0", port=5000, debug=True) 

