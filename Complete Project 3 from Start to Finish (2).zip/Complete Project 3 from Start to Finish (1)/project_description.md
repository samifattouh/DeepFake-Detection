# Project 3: Blockchain-based Fake Identification System

## Project Description

This project implements a system to combat the proliferation of counterfeit goods by leveraging blockchain technology for product authentication. In today's market, the presence of replicated and fake products causes significant confusion and erodes consumer trust, negatively impacting both users and legitimate companies. This system provides a reliable method to verify the authenticity of a product through its barcode.

The core of the system is a blockchain-based registry, implemented as a smart contract on an Ethereum-compatible blockchain (simulated using Ganache). Manufacturers or authorized entities can register genuine products by storing their unique barcode and relevant details (like model, version, etc.) immutably on the blockchain. 

When a consumer wants to verify a product, they can scan its barcode (simulated in this implementation via text input). The system then queries the smart contract using the scanned barcode. If the barcode exists in the registry, the system confirms the product as genuine. If the barcode is not found, the system flags the product as potentially fake or unregistered, alerting the user and preventing potentially harmful transactions.

This approach utilizes the inherent properties of blockchain technology – decentralization, immutability, and transparency – to create a trustworthy record of product authenticity. By storing registration data on a distributed ledger, the system minimizes the risk of data manipulation and provides a secure and reliable way for consumers and businesses to identify genuine products, thereby enhancing consumer safety and protecting brand reputation.
