document.addEventListener('DOMContentLoaded', () => {
    const barcodeInput = document.getElementById('barcode');
    const verifyBtn = document.getElementById('verifyBtn');
    const resultText = document.getElementById('resultText');

    verifyBtn.addEventListener('click', async () => {
        const barcode = barcodeInput.value.trim();

        if (!barcode) {
            resultText.textContent = 'Please enter a barcode.';
            resultText.className = ''; // Reset class
            return;
        }

        resultText.textContent = 'Verifying...';
        resultText.className = 'loading';

        try {
            // Make a POST request to the backend endpoint
            const response = await fetch('/verify', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ barcode: barcode }),
            });

            if (!response.ok) {
                // Handle HTTP errors (e.g., 404, 500)
                const errorData = await response.json().catch(() => ({ message: 'Server error' }));
                throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
            }

            const data = await response.json();

            // Update result based on backend response
            if (data.is_genuine) {
                resultText.textContent = `✅ Product with barcode "${barcode}" is GENUINE.`;
                resultText.className = 'genuine';
            } else {
                resultText.textContent = `🚨 WARNING: Product with barcode "${barcode}" is FAKE or NOT REGISTERED.`;
                resultText.className = 'fake';
            }

        } catch (error) {
            console.error('Verification error:', error);
            resultText.textContent = `Error during verification: ${error.message}. Please try again.`;
            resultText.className = 'fake'; // Use fake class for errors
        }
    });

    // Optional: Allow pressing Enter in the input field to trigger verification
    barcodeInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            verifyBtn.click();
        }
    });
});

