# User Manual: Blockchain-based Fake Identification System

## 1. Overview

This system allows users to verify the authenticity of products by checking their barcodes against a secure blockchain registry. It helps identify genuine products and warns users about potentially fake or unregistered items.

## 2. Prerequisites

To run this system, you need the following installed:

*   Python 3 (tested with 3.10+)
*   Node.js and npm (for Ganache)
*   Required Python libraries: `web3`, `py-solc-x`
*   Ganache (local blockchain): `npm install -g ganache`
*   Solidity Compiler (handled by `py-solc-x` script)

## 3. Setup

1.  **Clone/Download:** Obtain the project source code files:
    *   `ProductRegistry.sol` (Smart Contract)
    *   `compile_contract.py` (Compilation Script)
    *   `deploy_contract.py` (Deployment Script)
    *   `verify_product.py` (Verification & User Interaction Script)
    *   (Optional: `barcode_scanner.py` - currently integrated into `verify_product.py`)
2.  **Install Dependencies:**
    *   Navigate to the project directory in your terminal.
    *   Install Python libraries: `pip install web3 py-solc-x`
    *   Install Ganache globally: `npm install -g ganache`
3.  **Start Local Blockchain:**
    *   Open a new terminal window.
    *   Run the command: `ganache`
    *   Keep this terminal window open. Ganache will display available accounts and listen on `http://127.0.0.1:8545`.
4.  **Compile and Deploy Contract:**
    *   In the project directory terminal, run the compilation script: `python3 compile_contract.py`
    *   This will compile `ProductRegistry.sol` and create `contract_abi.json` and `contract_bytecode.bin`.
    *   Run the deployment script: `python3 deploy_contract.py`
    *   This will deploy the contract to your running Ganache instance and create `contract_config.json` containing the contract address and ABI.

## 4. Running the Verification System

1.  **Start Verification:**
    *   In the project directory terminal, run the main verification script: `python3 verify_product.py`
2.  **Register Test Products (Automatic):**
    *   The script will automatically connect to Ganache and use the first account to register a couple of sample products for testing purposes. You will see confirmation messages for registration.
3.  **Verify Barcodes:**
    *   The script will prompt you to `Enter product barcode to verify (or type 'exit' to quit):`.
    *   Enter a barcode string.
        *   Try `1234567890123` (should be GENUINE).
        *   Try `9876543210987` (should be GENUINE).
        *   Try any other string like `FAKE999` (should be FAKE or NOT REGISTERED).
    *   The system will query the blockchain and display the result:
        *   `✅ RESULT: Product with barcode [...] is GENUINE.`
        *   `🚨 WARNING: Product with barcode [...] is FAKE or NOT REGISTERED.`
4.  **Exit:**
    *   Type `exit` and press Enter to stop the verification script.

## 5. Registering New Products (Owner Only)

*   The `ProductRegistry.sol` contract has an `owner` (the account that deployed it, typically the first Ganache account).
*   Only the owner can register new products.
*   The `verify_product.py` script includes a helper function `register_product_for_testing` which demonstrates how registration is done via a transaction. For real-world use, a separate interface or script would be needed for authorized personnel to register products.
