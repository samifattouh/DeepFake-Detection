#!/usr/bin/env python3

"""
Interacts with the deployed ProductRegistry contract to verify product authenticity 
and notifies the user.
"""

import json
from web3 import Web3
import os

# Configuration
CONFIG_PATH = "contract_config.json"

def load_config(config_path):
    """Loads contract address, ABI, and RPC URL from config file."""
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
        return config["contract_address"], config["abi"], config["rpc_url"]
    except FileNotFoundError:
        print(f"Error: Configuration file not found at {config_path}")
        return None, None, None
    except KeyError as e:
        print(f"Error: Missing key {e} in configuration file {config_path}")
        return None, None, None

def verify_product(contract, barcode):
    """Calls the smart contract to check if the product barcode is registered."""
    print(f"Verifying barcode 	{barcode}	 with the blockchain...")
    try:
        is_genuine = contract.functions.isProductGenuine(barcode).call()
        return is_genuine
    except Exception as e:
        print(f"Error interacting with contract: {e}")
        # This could happen if the barcode format is wrong, contract reverted, etc.
        return False # Treat contract errors as potentially fake/unregistered

def notify_user(barcode, is_genuine):
    """Prints a notification message to the user based on verification result."""
    if is_genuine:
        print(f"\n✅ RESULT: Product with barcode 	{barcode}	 is GENUINE.")
        # Optionally, retrieve and display product details
        # try:
        #     details = contract.functions.getProductDetails(barcode).call()
        #     print(f"   Product Details: {details}")
        # except Exception as e:
        #     print(f"   Could not retrieve product details: {e}")
    else:
        print(f"\n🚨 WARNING: Product with barcode 	{barcode}	 is FAKE or NOT REGISTERED.")
        print("   Do not proceed with this product.")

# --- Optional: Function to register products (for testing) ---
def register_product_for_testing(w3, contract, owner_account, barcode, details):
    """Registers a product using the owner account. Only for testing setup."""
    try:
        print(f"\nAttempting to register product {barcode} as owner ({owner_account})...")
        tx_hash = contract.functions.registerProduct(barcode, details).transact({"from": owner_account})
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        print(f"Product {barcode} registered successfully. Transaction: {receipt.transactionHash.hex()}")
        return True
    except Exception as e:
        print(f"Error registering product {barcode}: {e}")
        return False
# --------------------------------------------------------------

if __name__ == "__main__":
    contract_address, contract_abi, rpc_url = load_config(CONFIG_PATH)

    if not all([contract_address, contract_abi, rpc_url]):
        print("Exiting due to configuration error.")
        exit(1)

    # Connect to blockchain
    w3 = Web3(Web3.HTTPProvider(rpc_url))
    if not w3.is_connected():
        print(f"Failed to connect to blockchain at {rpc_url}")
        exit(1)
    print(f"Connected to blockchain: {rpc_url}")

    # Instantiate contract
    product_registry_contract = w3.eth.contract(address=contract_address, abi=contract_abi)

    # --- Test Setup: Register some products (using Ganache account 0 as owner) ---
    owner = w3.eth.accounts[0]
    print(f"Using owner account for registration: {owner}")
    register_product_for_testing(w3, product_registry_contract, owner, "1234567890123", "Genuine Product A - Model X")
    register_product_for_testing(w3, product_registry_contract, owner, "9876543210987", "Genuine Product B - Version 2")
    register_product_for_testing(w3, product_registry_contract, owner, "9876543210986", "Genuine Product B - Version 2")
    register_product_for_testing(w3, product_registry_contract, owner, "01030816603", "Genuine Product B - Version 2")
    register_product_for_testing(w3, product_registry_contract, owner, "11", "Genuine Product B - Version 2")
    # -----------------------------------------------------------------------------

    # Simulate barcode scanning (using the previously created module)
    # For now, just prompt for input directly
    try:
        while True:
            barcode_to_check = input("\nEnter product barcode to verify (or type 'exit' to quit): ")
            if barcode_to_check.lower() == 'exit':
                break
            if not barcode_to_check:
                continue
            
            # Verify and Notify
            genuine_status = verify_product(product_registry_contract, barcode_to_check)
            notify_user(barcode_to_check, genuine_status)

    except KeyboardInterrupt:
        print("\nExiting verification system.")

    print("\nVerification process finished.")

