# TODO: Web Deployment of Blockchain Verification System

- [x] 012: Create web interface (HTML/CSS/JS).
- [x] 013: Adapt backend for web (Flask setup, install web3, copy ABI, create main.py).
- [ ] 014: Deploy smart contract to testnet (Modify deploy script, simulate deployment, update Flask config with placeholders).
- [ ] 015: Deploy web application (Update requirements.txt, use deploy tool).
- [ ] 016: Test deployed application.
