#!/usr/bin/env python3

"""
Barcode scanner for the Blockchain-based Fake Identification System.
This module simulates scanning a barcode and verifying it with the web application.
It can be used as a standalone command-line tool for testing.
"""

import requests
import sys
import time
import json
import argparse
from datetime import datetime

# Configuration
API_URL = "http://127.0.0.1:8080/verify"  # URL of the web application API

def scan_barcode():
    """Simulates scanning a barcode by prompting the user for input."""
    print("📷 Simulating barcode scanner...")
    print("Please enter a product barcode to scan:")
    barcode = input("> ")
    print(f"Scanned barcode: {barcode}")
    return barcode

def verify_barcode(barcode):
    """Sends the barcode to the verification API and returns the result."""
    print(f"Verifying barcode: {barcode}...")
    try:
        # Simulate scanning delay
        time.sleep(1)
        
        # Send request to API
        response = requests.post(
            API_URL, 
            json={"barcode": barcode},
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error: Server returned status code {response.status_code}")
            return {"error": f"Server error: {response.status_code}", "is_genuine": False}
    
    except requests.exceptions.ConnectionError:
        print("Error: Could not connect to the verification server.")
        print("Make sure the web application is running at", API_URL)
        return {"error": "Connection error", "is_genuine": False}
    
    except Exception as e:
        print(f"Error during verification: {e}")
        return {"error": str(e), "is_genuine": False}

def print_verification_result(result):
    """Prints the verification result in a user-friendly format."""
    print("\n" + "="*50)
    print("VERIFICATION RESULT")
    print("="*50)
    
    if result.get("is_genuine"):
        print("✅ AUTHENTIC PRODUCT VERIFIED")
        print(f"Product Name: {result.get('product_name', 'N/A')}")
        print(f"Manufacturer: {result.get('manufacturer', 'N/A')}")
        print(f"Registration Date: {result.get('registration_date', 'N/A')}")
        print(f"Blockchain Transaction: {result.get('blockchain_tx', 'N/A')}")
    else:
        print("❌ VERIFICATION FAILED")
        print(f"Reason: {result.get('details', result.get('error', 'Unknown'))}")
        print("This product may be counterfeit or not registered in the system.")
        
    print("="*50)

def main():
    """Main function that runs the barcode scanner application."""
    parser = argparse.ArgumentParser(description="Blockchain-based Fake Product Identification System")
    parser.add_argument("-b", "--barcode", help="Specify barcode directly without scanning simulation")
    parser.add_argument("-t", "--test", action="store_true", help="Run tests with predefined barcodes")
    
    args = parser.parse_args()
    
    print("\n" + "="*50)
    print("BLOCKCHAIN-BASED FAKE PRODUCT IDENTIFICATION")
    print("="*50)
    
    if args.test:
        # Test barcodes - both valid and invalid
        test_barcodes = [
            "1234567890123",  # Valid - Premium Smartphone
            "9876543210987",  # Valid - Genuine Product B
            "1111111111111",  # Invalid - Not registered
            "5678901234567",  # Valid - Smart Home Hub
        ]
        
        print("Running test with predefined barcodes...\n")
        
        for barcode in test_barcodes:
            print(f"\nTesting barcode: {barcode}")
            result = verify_barcode(barcode)
            print_verification_result(result)
            print("\nWaiting for next test...")
            time.sleep(2)
        
        print("\nTests completed.")
        return
    
    try:
        while True:
            # Get barcode either from arguments or by simulating scanning
            barcode = args.barcode if args.barcode else scan_barcode()
            
            # Only use the argument once, then revert to interactive mode
            args.barcode = None
            
            if not barcode:
                print("No barcode entered. Please try again.")
                continue
                
            # Verify the barcode
            result = verify_barcode(barcode)
            print_verification_result(result)
            
            # Ask if the user wants to scan another barcode
            print("\nScan another barcode? (y/n)")
            choice = input("> ").lower()
            if choice != 'y':
                break
    
    except KeyboardInterrupt:
        print("\nScanning session terminated.")
    
    print("\nThank you for using the Blockchain-based Fake Product Identification System.")

if __name__ == "__main__":
    main()

