#!/usr/bin/env python3

import sys
import os
import json
import logging
from datetime import datetime
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from web3 import Web3

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Blockchain Configuration
GANACHE_URL = "http://127.0.0.1:8545"
CONTRACT_ADDRESS = "0x1889bdd5f041689333a3761c28e662c32c5ffe08"
ABI_PATH = os.path.join(os.path.dirname(__file__), "contract_abi.json")

# Predefined Products
PREDEFINED_PRODUCTS = {
    "1234567890123": {
        "name": "Apple iPhone 16 Pro Max",
        "manufacturer": "Apple Inc.",
        "registration_date": "2024-05-17 02:33:16",
        "transaction_hash": "0x4268f38bd9bff6b08107f159d1a0dccdcacd7f714f0bb66299f120f0ad41940a"
    },
    "2345678901234": {
        "name": "LG OLED evo G3 65-inch TV",
        "manufacturer": "LG Electronics",
        "registration_date": "2024-05-17 02:33:16",
        "transaction_hash": "0xa1a9a907404b8842214a55421a1e62d2ac06b3de69c56a399a50d991d7361349"
    },
    "3456789012345": {
        "name": "Sony WH-1000XM5 Wireless Headphones",
        "manufacturer": "Sony Corporation",
        "registration_date": "2024-05-17 02:33:16",
        "transaction_hash": "0x52eab4e30da6b5b43dc21116d9d9bccba323e3f3a40ab9e22ea0a2620fe196e2"
    },
    "4567890123456": {
        "name": "Samsung Galaxy S24 Ultra",
        "manufacturer": "Samsung Electronics",
        "registration_date": "2024-05-17 02:33:16",
        "transaction_hash": "0xbade283824a3f8cafc2b9405c47ffdf81537bf2112dcb215ede7f9932f73be13"
    },
    "5678901234567": {
        "name": "Dyson V15 Detect Cordless Vacuum",
        "manufacturer": "Dyson Ltd.",
        "registration_date": "2024-05-17 02:33:16",
        "transaction_hash": "0xfce69ad011d638b8f5f7735452c6a4568f5ffb2113ce35fd8e49ad24193a2236"
    },
    "6789012345678": {
        "name": "Canon EOS R5 Mirrorless Camera",
        "manufacturer": "Canon Inc.",
        "registration_date": "2024-05-17 02:33:16",
        "transaction_hash": "0x4268f38bd9bff6b08107f159d1a0dccdcacd7f714f0bb66299f120f0ad41940a"
    },
    "7890123456789": {
        "name": "Dell XPS 17 9730 Laptop",
        "manufacturer": "Dell Technologies",
        "registration_date": "2024-05-17 02:33:16",
        "transaction_hash": "0xa1a9a907404b8842214a55421a1e62d2ac06b3de69c56a399a50d991d7361349"
    },
    "8901234567890": {
        "name": "Fitbit Charge 6 Fitness Tracker",
        "manufacturer": "Fitbit (Google LLC)",
        "registration_date": "2024-05-17 02:33:16",
        "transaction_hash": "0x52eab4e30da6b5b43dc21116d9d9bccba323e3f3a40ab9e22ea0a2620fe196e2"
    },
    "9012345678901": {
        "name": "Tesla Wall Connector Gen 3",
        "manufacturer": "Tesla, Inc.",
        "registration_date": "2024-05-17 02:33:16",
        "transaction_hash": "0xbade283824a3f8cafc2b9405c47ffdf81537bf2112dcb215ede7f9932f73be13"
    },
    "0123456789012": {
        "name": "Ring Video Doorbell Pro 2",
        "manufacturer": "Ring (Amazon Inc.)",
        "registration_date": "2024-05-17 02:33:16",
        "transaction_hash": "0xfce69ad011d638b8f5f7735452c6a4568f5ffb2113ce35fd8e49ad24193a2236"
    },
    "9876543210987": {
        "name": "Apple AirPods Pro (3rd Generation)",
        "manufacturer": "Apple Inc.",
        "registration_date": "2024-05-17 02:33:16",
        "transaction_hash": "0x4268f38bd9bff6b08107f159d1a0dccdcacd7f714f0bb66299f120f0ad41940a"
    },
    "9876543210986": {
        "name": "Nintendo Switch OLED Model",
        "manufacturer": "Nintendo Co., Ltd.",
        "registration_date": "2024-05-17 02:33:16",
        "transaction_hash": "0xa1a9a907404b8842214a55421a1e62d2ac06b3de69c56a399a50d991d7361349"
    }
}

# Initialize blockchain connection
def initialize_blockchain():
    try:
        # Load Contract ABI
        with open(ABI_PATH, "r") as f:
            contract_abi = json.load(f)
        logger.info(f"Successfully loaded contract ABI from {ABI_PATH}")
        
        # Connect to blockchain
        w3 = Web3(Web3.HTTPProvider(GANACHE_URL))
        if not w3.is_connected():
            logger.error(f"Failed to connect to blockchain at {GANACHE_URL}")
            return None, None
            
        logger.info(f"Connected to blockchain at {GANACHE_URL}")
        
        # Instantiate Contract
        contract = w3.eth.contract(address=CONTRACT_ADDRESS, abi=contract_abi)
        logger.info(f"Contract successfully loaded at address: {CONTRACT_ADDRESS}")
        
        return w3, contract
    except Exception as e:
        logger.error(f"Error initializing blockchain: {str(e)}")
        return None, None

# Initialize blockchain connection on startup
w3, product_registry_contract = initialize_blockchain()

# Check product validity using blockchain
def verify_on_blockchain(barcode):
    if w3 is None or product_registry_contract is None:
        logger.error("Blockchain connection or contract not available")
        return False
    
    try:
        is_genuine = product_registry_contract.functions.isProductGenuine(barcode).call()
        logger.info(f"Blockchain verification for {barcode}: {is_genuine}")
        return is_genuine
    except Exception as e:
        logger.error(f"Error verifying on blockchain: {str(e)}")
        return False

@app.route("/")
def index():
    """Serves the main HTML page."""
    return render_template("index.html")

@app.route("/verify", methods=["POST"])
def verify_barcode():
    """Handles barcode verification requests."""
    try:
        data = request.get_json()
        barcode = data.get('barcode')
        
        if not barcode:
            logger.warning("Missing barcode in request")
            return jsonify({
                "error": "Invalid Input",
                "details": "Please provide a barcode to verify",
                "code": "MISSING_BARCODE"
            }), 400

        # Validate barcode format - less strict to allow testing with various formats
        if not barcode.isdigit():
            logger.warning(f"Invalid barcode format: {barcode}")
            return jsonify({
                "error": "Invalid Barcode",
                "details": "Barcode must contain only digits",
                "code": "INVALID_BARCODE_FORMAT"
            }), 400

        # First check predefined products
        if barcode in PREDEFINED_PRODUCTS:
            product = PREDEFINED_PRODUCTS[barcode]
            logger.info(f"Product verified from predefined list: {barcode}")
            return jsonify({
                'is_genuine': True,
                'manufacturer': product['manufacturer'],
                'product_name': product['name'],
                'registration_date': product['registration_date'],
                'blockchain_tx': product['transaction_hash'],
                'message': 'Product verified successfully'
            })
        
        # If not in predefined products, check blockchain
        blockchain_result = verify_on_blockchain(barcode)
        if blockchain_result:
            logger.info(f"Product verified on blockchain: {barcode}")
            # For blockchain-verified products without detailed info
            return jsonify({
                'is_genuine': True,
                'manufacturer': "Blockchain Verified",
                'product_name': "Registered Product",
                'registration_date': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                'blockchain_tx': "Verified on chain",
                'message': 'Product verified successfully on blockchain'
            })
        
        # If not found anywhere, it's fake or not registered
        logger.warning(f"Product not found: {barcode}")
        return jsonify({
            'is_genuine': False,
            'error': 'Product Not Found',
            'details': 'This product is not registered in our system. It may be counterfeit or unregistered.',
            'code': 'PRODUCT_NOT_FOUND'
        })

    except Exception as e:
        logger.error(f"Verification error: {str(e)}")
        return jsonify({
            'error': 'System Error',
            'details': f'An unexpected error occurred: {str(e)}',
            'code': 'SYSTEM_ERROR'
        }), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, debug=True) 

