document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const barcodeInput = document.getElementById('barcode');
    const verifyBtn = document.getElementById('verifyBtn');
    const scanBtn = document.getElementById('scanBtn');
    const resultArea = document.getElementById('resultArea');
    const resultText = document.getElementById('resultText');
    const resultIcon = resultArea.querySelector('.result-icon i');
    const loadingOverlay = document.getElementById('loadingOverlay');
    const productDetails = document.getElementById('productDetails');
    const cameraModal = document.getElementById('cameraModal');
    const cameraFeed = document.getElementById('cameraFeed');
    const closeCameraBtn = document.getElementById('closeCameraBtn');
    const scanStatus = document.getElementById('scanStatus');

    // Camera scanning variables
    let stream = null;
    let barcodeDetector = null;

    // Initialize barcode detector if available
    if ('BarcodeDetector' in window) {
        barcodeDetector = new BarcodeDetector({
            formats: ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_39', 'code_128', 'qr_code']
        });
    }

    // Input validation - only allow digits
    barcodeInput.addEventListener('input', (e) => {
        e.target.value = e.target.value.replace(/[^0-9]/g, '');
    });

    // Focus styles
    barcodeInput.addEventListener('focus', () => {
        barcodeInput.parentElement.classList.add('focused');
    });

    barcodeInput.addEventListener('blur', () => {
        barcodeInput.parentElement.classList.remove('focused');
    });

    // Scan button functionality
    scanBtn.addEventListener('click', async () => {
        try {
            if (!('mediaDevices' in navigator) || !('getUserMedia' in navigator.mediaDevices)) {
                alert('Camera access not supported by your browser. Please enter the barcode manually.');
                return;
            }
            
            stream = await navigator.mediaDevices.getUserMedia({ 
                video: { facingMode: 'environment' } 
            });
            cameraFeed.srcObject = stream;
            cameraModal.classList.add('active');
            startBarcodeScanning();
        } catch (error) {
            console.error('Camera access error:', error);
            alert('Unable to access camera. Please ensure camera permissions are granted and try again.');
        }
    });

    closeCameraBtn.addEventListener('click', () => {
        stopCamera();
    });

    async function startBarcodeScanning() {
        if (!barcodeDetector) {
            scanStatus.textContent = 'Barcode detection not supported in this browser. Please use a different browser or enter the barcode manually.';
            return;
        }

        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        scanStatus.textContent = 'Scanning for barcode...';

        async function scanFrame() {
            if (!stream || !cameraFeed.videoWidth) {
                requestAnimationFrame(scanFrame);
                return;
            }

            try {
                canvas.width = cameraFeed.videoWidth;
                canvas.height = cameraFeed.videoHeight;
                context.drawImage(cameraFeed, 0, 0);

                const barcodes = await barcodeDetector.detect(canvas);
                
                if (barcodes.length > 0) {
                    const barcode = barcodes[0].rawValue;
                    scanStatus.textContent = `Barcode detected: ${barcode}`;
                    barcodeInput.value = barcode;
                    
                    // Wait a moment to show the detected barcode before closing
                    setTimeout(() => {
                        stopCamera();
                        verifyBtn.click();
                    }, 1000);
                    return;
                }
            } catch (error) {
                console.error('Scanning error:', error);
                scanStatus.textContent = 'Error during scanning. Please try again.';
            }

            requestAnimationFrame(scanFrame);
        }

        scanFrame();
    }

    function stopCamera() {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            stream = null;
        }
        cameraModal.classList.remove('active');
    }

    // Verify button click handler
    verifyBtn.addEventListener('click', async () => {
        const barcode = barcodeInput.value.trim();

        if (!barcode) {
            showError({
                code: 'MISSING_BARCODE',
                details: 'Please enter a barcode to verify'
            });
            return;
        }

        // Don't require exactly 13 digits to allow testing with various barcode formats
        if (!barcode.match(/^\d+$/)) {
            showError({
                code: 'INVALID_BARCODE_FORMAT',
                details: 'Barcode must contain only digits'
            });
            return;
        }

        setLoading(true);
        resetResultArea();

        try {
            const response = await fetch('/verify', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ barcode })
            });

            const data = await response.json();

            if (!response.ok) {
                throw data;
            }

            if (data.is_genuine) {
                updateProductDetails(data);
                showSuccess(barcode, data);
            } else {
                hideProductDetails();
                showError(data);
            }

        } catch (error) {
            console.error('Verification error:', error);
            hideProductDetails();
            showError(error);
        } finally {
            setLoading(false);
        }
    });

    // Enter key handler for barcode input
    barcodeInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            event.preventDefault();
            verifyBtn.click();
        }
    });

    // Helper functions
    function resetResultArea() {
        resultArea.className = 'result-area';
        productDetails.classList.add('hidden');
        resultText.textContent = 'Verifying product...';
        resultIcon.className = 'fas fa-spinner fa-spin';
    }

    function updateProductDetails(data) {
        document.getElementById('productName').textContent = data.product_name || 'N/A';
        document.getElementById('manufacturer').textContent = data.manufacturer || 'N/A';
        document.getElementById('regDate').textContent = data.registration_date || 'N/A';
        document.getElementById('blockchainStatus').textContent = data.blockchain_tx ? 'Verified on Blockchain' : 'N/A';
        productDetails.classList.remove('hidden');
    }

    function hideProductDetails() {
        productDetails.classList.add('hidden');
    }

    function setLoading(isLoading) {
        loadingOverlay.classList.toggle('active', isLoading);
        verifyBtn.disabled = isLoading;
        barcodeInput.disabled = isLoading;
    }

    function showSuccess(barcode, data) {
        resultArea.className = 'result-area genuine';
        resultIcon.className = 'fas fa-check-circle';
        resultText.innerHTML = `
            <strong>✅ Genuine Product</strong><br>
            Barcode: ${formatBarcode(barcode)}<br>
            <small>${data.message || 'This product has been verified as authentic'}</small>
        `;
        
        animateResult();
    }

    function showError(errorData) {
        resultArea.className = 'result-area fake';
        resultIcon.className = 'fas fa-exclamation-circle';
        
        let errorMessage = '';

        switch(errorData.code) {
            case 'PRODUCT_NOT_FOUND':
                errorMessage = `
                    <strong>⚠️ Verification Failed</strong><br>
                    ${errorData.details || 'Product not found in our database'}<br>
                    <small>This product may be counterfeit or unregistered</small>
                `;
                break;
            case 'INVALID_BARCODE_FORMAT':
                errorMessage = `
                    <strong>⚠️ Invalid Barcode Format</strong><br>
                    ${errorData.details || 'Please check the barcode format'}<br>
                    <small>Enter a valid barcode number</small>
                `;
                break;
            default:
                errorMessage = `
                    <strong>⚠️ Error</strong><br>
                    ${errorData.details || errorData.error || 'An unexpected error occurred'}<br>
                    <small>Please try again</small>
                `;
        }

        resultText.innerHTML = errorMessage;
        animateResult();
    }

    function animateResult() {
        resultArea.style.animation = 'none';
        resultArea.offsetHeight; // Trigger reflow
        resultArea.style.animation = 'statusChange 0.3s ease-out';
    }

    function formatBarcode(barcode) {
        // Format barcode numbers with dashes for better readability
        if (barcode.length === 13) {
            return barcode.replace(/(\d{1})(\d{6})(\d{6})/, '$1-$2-$3');
        } else if (barcode.length > 8) {
            // Generic formatting for other barcode lengths
            return barcode.replace(/(.{4})/g, '$1-').replace(/-$/, '');
        }
        return barcode;
    }
});

